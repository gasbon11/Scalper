import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const userPreferences = mysqlTable("userPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  language: varchar("language", { length: 10 }).default("en").notNull(),
  defaultExchange: varchar("defaultExchange", { length: 50 }).default("binance").notNull(),
  defaultMarketMode: varchar("defaultMarketMode", { length: 10 }).default("spot").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = typeof userPreferences.$inferInsert;

export const marketMetadata = mysqlTable("marketMetadata", {
  id: int("id").autoincrement().primaryKey(),
  exchange: varchar("exchange", { length: 50 }).notNull(),
  marketMode: varchar("marketMode", { length: 10 }).notNull(),
  symbol: varchar("symbol", { length: 100 }).notNull(),
  baseAsset: varchar("baseAsset", { length: 50 }).notNull(),
  quoteAsset: varchar("quoteAsset", { length: 50 }).notNull(),
  pricePrecision: int("pricePrecision").notNull(),
  amountPrecision: int("amountPrecision").notNull(),
  minPrice: varchar("minPrice", { length: 100 }),
  maxPrice: varchar("maxPrice", { length: 100 }),
  minAmount: varchar("minAmount", { length: 100 }),
  maxAmount: varchar("maxAmount", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MarketMetadata = typeof marketMetadata.$inferSelect;
export type InsertMarketMetadata = typeof marketMetadata.$inferInsert;