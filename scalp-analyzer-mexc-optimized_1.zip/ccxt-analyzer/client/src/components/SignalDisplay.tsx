import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { TrendingUp, TrendingDown, AlertCircle, Activity } from 'lucide-react';
import TPSLDisplay from './TPSLDisplay';

interface TechnicalSignal {
  timeframe: string;
  vwap?: number;
  ema9?: number;
  ema21?: number;
  rsi14?: number;
  atr?: number;
  bias: 'long' | 'short' | 'neutral';
  strength: 'strong' | 'weak';
}

interface TrendSignal15m {
  trend: 'strong_long' | 'strong_short' | 'neutral';
  diffPercent: number;
  open3CandlesAgo: number;
  currentClose: number;
}

interface DecisionResult {
  decision: 'LONG' | 'SHORT' | 'WAIT';
  signals: {
    '5m': TechnicalSignal;
    '3m': TechnicalSignal;
    '1m': TechnicalSignal;
  };
  trend15m?: TrendSignal15m;
  tpSl?: any;
}

export default function SignalDisplay({ data }: { data: DecisionResult }) {
  const { t } = useLanguage();

  const formatPrice = (price: number | undefined): string => {
    if (!price) return '—';
    // Tam hassasiyet — sıfırları kırp ama minimum 2 ondalık
    const str = price.toFixed(8);
    const trimmed = str.replace(/\.?0+$/, '');
    return trimmed.includes('.') ? trimmed : trimmed + '.00';
  };

  const getSignalColor = (bias: string) => {
    if (bias === 'long') return 'text-accent';
    if (bias === 'short') return 'text-destructive';
    return 'text-muted-foreground';
  };

  const getSignalIcon = (bias: string) => {
    if (bias === 'long') return <TrendingUp className="h-4 w-4" />;
    if (bias === 'short') return <TrendingDown className="h-4 w-4" />;
    return <AlertCircle className="h-4 w-4" />;
  };

  const getBiasLabel = (bias: string) => {
    if (bias === 'long') return t('signal.bias.long');
    if (bias === 'short') return t('signal.bias.short');
    return t('signal.neutral');
  };

  const isLong = data.decision === 'LONG';
  const isShort = data.decision === 'SHORT';
  const isWait = data.decision === 'WAIT';

  const decisionLabel = isLong
    ? t('signal.long')
    : isShort
    ? t('signal.short')
    : t('signal.wait');

  const decisionBorderClass = isLong
    ? 'border-accent'
    : isShort
    ? 'border-destructive'
    : 'border-yellow-500';

  const decisionTextClass = isLong
    ? 'text-accent'
    : isShort
    ? 'text-destructive'
    : 'text-yellow-400';

  // 15m trend renk ve etiket
  const get15mTrendColor = (trend: string) => {
    if (trend === 'strong_long') return 'text-accent';
    if (trend === 'strong_short') return 'text-destructive';
    return 'text-muted-foreground';
  };

  const get15mTrendLabel = (trend: string) => {
    if (trend === 'strong_long') return t('trend15m.strong_long');
    if (trend === 'strong_short') return t('trend15m.strong_short');
    return t('trend15m.neutral');
  };

  const showTrend15m =
    data.trend15m &&
    (data.decision === 'LONG' || data.decision === 'SHORT') &&
    data.trend15m.trend !== 'neutral';

  return (
    <div className="space-y-6">
      {/* ===== ANA KARAR — EN ÜSTTE ===== */}
      <Card className={`bg-card border-2 ${decisionBorderClass}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">{t('signal.decision')}</CardTitle>
            <div className={`text-4xl font-extrabold tracking-wide ${decisionTextClass}`}>
              {decisionLabel}
            </div>
          </div>
        </CardHeader>

        {/* 15m Trend Notu — sadece LONG/SHORT sinyalinde, fiyatın hemen altında */}
        {showTrend15m && data.trend15m && (
          <CardContent className="pt-0">
            <div
              className={`flex items-center gap-2 rounded-md border px-3 py-2 text-sm font-semibold ${
                data.trend15m.trend === 'strong_long'
                  ? 'border-accent/40 bg-accent/10 text-accent'
                  : 'border-destructive/40 bg-destructive/10 text-destructive'
              }`}
            >
              <Activity className="h-4 w-4 shrink-0" />
              <span>
                {t('trend15m.label')}:{' '}
                <span className="font-bold">{get15mTrendLabel(data.trend15m.trend)}</span>
                <span className="ml-2 text-xs opacity-70">
                  ({data.trend15m.diffPercent >= 0 ? '+' : ''}
                  {data.trend15m.diffPercent.toFixed(3)}%)
                </span>
              </span>
            </div>
          </CardContent>
        )}
      </Card>

      {/* ===== TP/SL DISPLAY — DECISION ALTINDA ===== */}
      {data.tpSl && (data.decision === 'LONG' || data.decision === 'SHORT') && (
        <TPSLDisplay tpSl={data.tpSl} />
      )}

      {/* ===== 1-3-5m ZAMAN DİLİMİ SİNYALLERİ ===== */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 5-Minute */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">{t('signal.timeframe5m')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{t('signal.bias')}</span>
              <div
                className={`flex items-center gap-1 font-semibold ${getSignalColor(data.signals['5m'].bias)}`}
              >
                {getSignalIcon(data.signals['5m'].bias)}
                {getBiasLabel(data.signals['5m'].bias)}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{t('signal.strength')}</span>
              <Badge
                variant={data.signals['5m'].strength === 'strong' ? 'default' : 'secondary'}
              >
                {t(`signal.${data.signals['5m'].strength}`)}
              </Badge>
            </div>
            {data.signals['5m'].vwap && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{t('price.vwap')}</span>
                <span className="font-mono text-foreground">
                  {formatPrice(data.signals['5m'].vwap)}
                </span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 3-Minute */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">{t('signal.timeframe3m')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{t('signal.bias')}</span>
              <div
                className={`flex items-center gap-1 font-semibold ${getSignalColor(data.signals['3m'].bias)}`}
              >
                {getSignalIcon(data.signals['3m'].bias)}
                {getBiasLabel(data.signals['3m'].bias)}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{t('signal.strength')}</span>
              <Badge
                variant={data.signals['3m'].strength === 'strong' ? 'default' : 'secondary'}
              >
                {t(`signal.${data.signals['3m'].strength}`)}
              </Badge>
            </div>
            {data.signals['3m'].rsi14 && (
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">{t('price.rsi')}</span>
                  <span className="font-mono text-foreground">
                    {data.signals['3m'].rsi14.toFixed(2)}
                  </span>
                </div>
                {data.signals['3m'].ema9 && (
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">{t('price.ema9')}</span>
                    <span className="font-mono text-foreground">
                      {formatPrice(data.signals['3m'].ema9)}
                    </span>
                  </div>
                )}
                {data.signals['3m'].ema21 && (
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">{t('price.ema21')}</span>
                    <span className="font-mono text-foreground">
                      {formatPrice(data.signals['3m'].ema21)}
                    </span>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 1-Minute */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">{t('signal.timeframe1m')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{t('signal.bias')}</span>
              <div
                className={`flex items-center gap-1 font-semibold ${getSignalColor(data.signals['1m'].bias)}`}
              >
                {getSignalIcon(data.signals['1m'].bias)}
                {getBiasLabel(data.signals['1m'].bias)}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{t('signal.strength')}</span>
              <Badge
                variant={data.signals['1m'].strength === 'strong' ? 'default' : 'secondary'}
              >
                {t(`signal.${data.signals['1m'].strength}`)}
              </Badge>
            </div>
            {data.signals['1m'].ema9 && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{t('price.ema9')}</span>
                <span className="font-mono text-foreground">
                  {formatPrice(data.signals['1m'].ema9)}
                </span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
