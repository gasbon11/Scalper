import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { Target, AlertTriangle } from 'lucide-react';

interface TPSL {
  entry: number;
  sl: number;
  tp1: number;
  tp2: number;
  riskReward1: string;
  riskReward2: string;
}

/**
 * Futures tam basamak hassasiyetiyle fiyat formatla
 * Örn: 0.00064210 — sondaki sıfırları koru (min 8 ondalık)
 */
function formatFuturesPrice(price: number): string {
  if (!price) return '0';
  // Fiyatın büyüklüğüne göre ondalık basamak belirle
  if (price >= 1000) return price.toFixed(2);
  if (price >= 1) return price.toFixed(4);
  if (price >= 0.01) return price.toFixed(6);
  return price.toFixed(8);
}

export default function TPSLDisplay({ tpSl }: { tpSl: TPSL }) {
  const { t } = useLanguage();

  const risk = Math.abs(tpSl.entry - tpSl.sl);
  const reward1 = Math.abs(tpSl.tp1 - tpSl.entry);
  const reward2 = Math.abs(tpSl.tp2 - tpSl.entry);

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5 text-accent" />
          {t('tp.title')} & {t('tp.sl')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Stop Loss */}
          <div className="rounded-lg bg-destructive/10 p-4 border border-destructive/30">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <span className="text-sm font-medium text-destructive">{t('tp.sl')}</span>
              </div>
              <span className="text-lg font-bold text-destructive font-mono">
                {formatFuturesPrice(tpSl.sl)}
              </span>
            </div>
            <div className="text-xs text-destructive/70">
              Risk: {formatFuturesPrice(risk)} ({((risk / tpSl.entry) * 100).toFixed(3)}%)
            </div>
          </div>

          {/* Take Profit Levels */}
          <div className="space-y-3">
            {/* TP1 */}
            <div className="rounded-lg bg-accent/10 p-4 border border-accent/30">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-accent">{t('tp.tp1')}</span>
                <span className="text-lg font-bold text-accent font-mono">
                  {formatFuturesPrice(tpSl.tp1)}
                </span>
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex items-center justify-between text-muted-foreground">
                  <span>Profit:</span>
                  <span className="text-accent font-mono">
                    +{formatFuturesPrice(reward1)} ({((reward1 / tpSl.entry) * 100).toFixed(3)}%)
                  </span>
                </div>
                <div className="flex items-center justify-between text-muted-foreground">
                  <span>{t('tp.riskReward')}:</span>
                  <span className="text-accent font-mono">{tpSl.riskReward1}</span>
                </div>
              </div>
            </div>

            {/* TP2 */}
            <div className="rounded-lg bg-accent/10 p-4 border border-accent/30">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-accent">{t('tp.tp2')}</span>
                <span className="text-lg font-bold text-accent font-mono">
                  {formatFuturesPrice(tpSl.tp2)}
                </span>
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex items-center justify-between text-muted-foreground">
                  <span>Profit:</span>
                  <span className="text-accent font-mono">
                    +{formatFuturesPrice(reward2)} ({((reward2 / tpSl.entry) * 100).toFixed(3)}%)
                  </span>
                </div>
                <div className="flex items-center justify-between text-muted-foreground">
                  <span>{t('tp.riskReward')}:</span>
                  <span className="text-accent font-mono">{tpSl.riskReward2}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Risk Summary */}
          <div className="rounded-lg bg-muted/30 p-4 border border-border">
            <div className="text-xs text-muted-foreground space-y-1">
              <p>
                <strong>Risk per trade:</strong> {formatFuturesPrice(risk)}
              </p>
              <p>
                <strong>Potential profit (TP1):</strong> {formatFuturesPrice(reward1)} ({tpSl.riskReward1})
              </p>
              <p>
                <strong>Potential profit (TP2):</strong> {formatFuturesPrice(reward2)} ({tpSl.riskReward2})
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
