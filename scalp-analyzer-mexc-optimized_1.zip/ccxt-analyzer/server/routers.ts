import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // CCXT and Technical Analysis routes
  market: router({
    searchMarkets: publicProcedure
      .input((val: any) => ({
        exchange: val.exchange as string,
        marketMode: val.marketMode as string,
        searchTerm: val.searchTerm as string,
      }))
      .query(async ({ input }) => {
        const { searchMarkets } = await import('./ccxt-service');
        return await searchMarkets(input.exchange as any, input.marketMode as any, input.searchTerm);
      }),

    getOHLCV: publicProcedure
      .input((val: any) => ({
        exchange: val.exchange as string,
        symbol: val.symbol as string,
        timeframe: val.timeframe as string,
      }))
      .query(async ({ input }) => {
        const { fetchOHLCV } = await import('./ccxt-service');
        return await fetchOHLCV(input.exchange as any, input.symbol, input.timeframe, 100, 'futures');
      }),

    getMultiTimeframeOHLCV: publicProcedure
      .input((val: any) => ({
        exchange: val.exchange as string,
        symbol: val.symbol as string,
      }))
      .query(async ({ input }) => {
        const { fetchMultiTimeframeOHLCV } = await import('./ccxt-service');
        return await fetchMultiTimeframeOHLCV(input.exchange as any, input.symbol, ['1m', '3m', '5m', '15m'], 'futures');
      }),

    getTicker: publicProcedure
      .input((val: any) => ({
        exchange: val.exchange as string,
        symbol: val.symbol as string,
      }))
      .query(async ({ input }) => {
        const { fetchTicker } = await import('./ccxt-service');
        // Futures baz al
        return await fetchTicker(input.exchange as any, input.symbol, 'futures');
      }),
  }),

  analysis: router({
    getSignal: publicProcedure
      .input((val: any) => ({
        exchange: val.exchange as string,
        symbol: val.symbol as string,
      }))
      .query(async ({ input }) => {
        const { fetchMultiTimeframeOHLCV } = await import('./ccxt-service');
        const { analyzeMultiTimeframe } = await import('./technical-analysis');

        // 1m, 3m, 5m ve 15m verilerini çek (futures)
        const data = await fetchMultiTimeframeOHLCV(
          input.exchange as any,
          input.symbol,
          ['1m', '3m', '5m', '15m'],
          'futures'
        );
        const candles1m = data.find((d) => d.timeframe === '1m')?.candles || [];
        const candles3m = data.find((d) => d.timeframe === '3m')?.candles || [];
        const candles5m = data.find((d) => d.timeframe === '5m')?.candles || [];
        const candles15m = data.find((d) => d.timeframe === '15m')?.candles || [];

        return analyzeMultiTimeframe(candles1m, candles3m, candles5m, candles15m);
      }),
  }),
});

export type AppRouter = typeof appRouter;
